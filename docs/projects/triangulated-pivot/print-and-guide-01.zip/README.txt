V4.2 — Learn Fusion by Building a Triangulated Pivot

Reference envelope: regular octagon, 150 mm across opposite flats, 260 mm
overall straight length. Two integrated printed housings use the retained
two-608-bearing / 8 mm metal-shaft core.

Read guide.html for the illustrated lesson. Select any image to enlarge it;
Actual size helps with fine labels and Escape returns to the lesson. The full
text and figures also work with JavaScript disabled.

The walkthrough polish adds linked step references, previous/next navigation,
and a Contents menu that stays available on a phone. The assembly phases have
their own headings. Start with the first bearing-ring pair and sleeve/nut
sample; the guide offers supplied variants for the remaining fit comparisons.

Revision 4.2 expands the beginner teaching, examples and troubleshooting.
CAD and print geometry are unchanged from V4.1; the geometry-continuity
report records their hashes. Historical digital reports retain their dates
and original scope. This release does not add physical test results.

Extract all numbered native-CAD
and print-and-guide zip volumes into the same folder beside the HTML file,
preserving their internal paths. The portable index.html also uses the images
and downloads in that folder. Individual native and print files are linked
throughout the lesson.

checkpoints/ contains editable Fusion F3D checkpoints and a STEP exchange
assembly. Use checkpoint 15 for the final print-edge-refined assembly;
earlier main checkpoints retain the preceding lesson stages. The native
checkpoints preserve modeling history. The STEP model
exchanges geometry; it does not preserve the lesson's sketch constraints.

print-files/ contains the documented print meshes. Import at 100% scale in
millimeters. Files ending in print-orientation.stl are already oriented; keep
their bed yaw and disable rotation in Arrange. Fit trials are already oriented
as named. Do not export or print the REF hardware envelopes.

Main assembly quantities: one each A, B, C, D, E and F.
Fixture quantities: two end backers, two clamp shoes and one setup block.
Fit variants: eight bearing trials and three sleeve/nut trials.
Exact local process trials: A0 distal rim and A90 shallow brace.

Follow the support process for A/B, both brace trials, mouth-down bearing
trials and sleeve/nut blocks. Remove support/interface material before judging
fits. Inspect the small trials before committing to a full housing.

parameters.csv, facet-coordinates.csv and spoke-coordinates.csv provide the
reference dimensions and driving expressions. Fit, brace-trial and load-test
CSV logs are blank recording sheets for the builder's measurements. Load testing
uses load-baseline-log.csv for each setup, load-test-log.csv for individual
cycles, and load-summary-log.csv for separate repeatability spreads.

Digital reports describe the native, mesh and slicing checks and their limits.
Filament/time values are slicer estimates, not measured printer performance.
The supplied design has not been physically printed, assembled or load-tested.
The guide's proposed loads are experimental increments, not a payload rating.

The new larger envelope needs suitable workholding: the 150 mm housing and
two 6 mm clamp shoes require at least 162 mm vise opening, plus lining and
handling clearance. Read the complete fixture and insertion sequence first.
